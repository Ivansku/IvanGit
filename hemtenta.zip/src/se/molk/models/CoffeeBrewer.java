package se.molk.models;

public class CoffeeBrewer {
    private CoffeeCup[] coffeeCups;

    public CoffeeBrewer(int numberOfCupsToBrew) {
    }

    public CoffeeCup[] getCoffeeCups() {
        return coffeeCups;
    }
}
